<?php

$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "db_p";

//create connection
$conn = new mysqli($servername, $username, $password, $dbname) or die("Database Not Connected");


if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	if (isset($_POST['submit'])) {

		if (isset($_POST['term'])) {
			$user_id = $_POST['user_id'];
			$username =  $_POST['username'];
			$useremail = $_POST['email'];
			$userpassword =  $_POST['password'];
			$userage =  $_POST['age'];
			$userphone = $_POST['phone'];
			$usergender =  $_POST['gender'];
			$cpassword = $_POST['cpassword'];


			function validate($form_data)
			{
				$form_data = trim(stripcslashes(htmlspecialchars($form_data)));
				return $form_data;
			}
			// $vuser_id = validate($user_id);
			// $vusername = validate($username);
			// $vuseremail = validate($useremail);
			// $vuserpassword = validate($userpassword);
			// $vuserphone = validate($userphone);
			// $vusergender = validate($usergender);


			if (!empty($username) && !empty($useremail) && !empty($userpassword) && !empty($userphone) && !empty($usergender)) {

				//$pass = password_hash($vuserpassword, PASSWORD_BCRYPT);
				if ($cpassword == $userpassword) {
					$insert = "INSERT INTO  users (user_id,username, email, phone, gender, age, password) 
				VALUES (NULL, '$username', '$useremail', '$userphone', '$usergender', '$userage', '$userpassword')";
					mysqli_query($conn, $insert);
					$msg = "User Inserted";

					// else
					// {
					echo $username;
					echo $useremail;
					echo $userpassword;
					echo $userphone;
					echo $usergender;

					// 	$msg = "Not Inserted";
					// }
					header('Location: home.php');
				} else {
					$msg = "password in not same";
				}
			}
		} else {
			$msg = "Please Check Term And Condition";
		}
	}
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Register User</title>
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">

</head>

<body>
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-6">
				<h1>Registration</h1>
				<form name="registration" action="" method="post">
					<div class="form-group">
						<label for="username" style="color: white;">Username</label>
						<input type="text" name="username" placeholder="Username" require></br>
					</div>
					<div class="form-group">
						<label for="email" style="color: white;">Email</label>
						<input type="email" name="email" placeholder="Email" require></br>
					</div>
					<div class="form-group">
						<label for="number" style="color: white;">Phone</label>
						<input type="number" name="phone" placeholder="Phone" require></br>
					</div>
					<div class="form-group">
						<label for="gender" style="color: white;">Gender</label>
						<select class="form-control" name="gender">
							<option value="Male"> Male</option>
							<option value="Female"> Female</option>
							<option value="Other"> Other</option>
						</select></br>
					</div>

					<div class="form-group">
						<label for="number" style="color: white;">Age</label>
						<input type="number" name="age" placeholder="Age" min="1" require></br>
					</div>
					<div class="form-group">
						<label for="password" style="color: white;">Password</label>
						<input type="password" name="password" placeholder="Password" require></br>
					</div>
					<label for="password" style="color: white;"> </label>
					<input type="password" name="cpassword" placeholder="Confirm Password" onchange="check()" require></br>
					<input type="checkbox" name="term"> I Follow All Term & Condition <br>

					<button type="submit" name="submit" value="Register">Register</button>


				</form>
				<h3 style="color:red;"><?php echo @$msg; ?></h3>
			</div>
		</div>
	</div>



	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
	<script type="text/javascript" src="js/bootstrap.bundle.min.js"></script>
</body>

</html>